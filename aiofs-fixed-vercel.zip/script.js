document.getElementById('loginForm').addEventListener('submit', function(event) {
  event.preventDefault();
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  if (email === "admin@aiofs.com" && password === "admin123") {
    window.location.href = "admin.html";
  } else if (email && password) {
    window.location.href = "dashboard.html";
  } else {
    alert("Invalid login credentials");
  }
});