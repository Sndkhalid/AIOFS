# AIOFS – All In One Financial Services

A fully responsive website for a multi-functional financial service platform offering:
- 🔐 Secure login system (user + admin access)
- 💼 Credit repair and mentorship tools
- 📈 Affiliate & Forex dashboards
- 🛡️ Crypto dispute resolution
- 🛍️ Online store
- 💸 Cryptocurrency-based payments

## 🛠 Tech Stack
- HTML5, CSS3, JavaScript
- Responsive Design
- Deployable via GitHub + Vercel

## 🔗 Live Demo
Once deployed, your site will be available at:
```
https://your-project-name.vercel.app
```

## 🚀 How to Deploy

### 1. Upload to GitHub
```bash
git init
git remote add origin https://github.com/your-username/aiofs-site.git
git add .
git commit -m "Initial commit"
git push -u origin main
```

### 2. Deploy on Vercel
- Go to [https://vercel.com](https://vercel.com)
- Import this GitHub repo
- Click “Deploy”

## 📁 Folder Structure
```
.
├── index.html
├── dashboard.html
├── admin.html
├── store.html
├── logout.html
├── styles.css
├── script.js
└── README.md
```

> Developed for All In One Financial Services (AIOFS)